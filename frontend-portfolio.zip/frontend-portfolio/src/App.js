
import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'Arial', padding: '20px' }}>
      <h1>Swapon Mondal</h1>
      <h2>Frontend Developer</h2>
      <p>Email: rbsawpon79@gmail.com</p>
      <p>Phone: 01604533887</p>
      <p>GitHub: <a href="https://github.com/rbsawpon8621" target="_blank">rbsawpon8621</a></p>
    </div>
  );
}

export default App;
